import React from 'react';
import { motion } from 'framer-motion';
import { Zap, Github, Twitter, Mail } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-card border-t border-border">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <motion.div
                whileHover={{ rotate: 360 }}
                transition={{ duration: 0.5 }}
                className="p-2 rounded-lg bg-primary/10 border border-primary/20"
              >
                <Zap className="h-6 w-6 text-neon-blue neon-glow" />
              </motion.div>
              <span className="text-xl font-bold text-neon-blue neon-text">
                Energize AI
              </span>
            </div>
            <p className="text-muted-foreground mb-4 max-w-md">
              Your next-generation AI assistant platform. Empowering productivity, 
              creativity, and problem-solving through intelligent automation and 
              personalized AI interactions.
            </p>
            <div className="flex space-x-4">
              <motion.a
                href="#"
                whileHover={{ scale: 1.1 }}
                className="p-2 rounded-lg bg-accent/10 hover:bg-accent/20 smooth-transition"
              >
                <Github className="h-5 w-5 text-neon-purple" />
              </motion.a>
              <motion.a
                href="#"
                whileHover={{ scale: 1.1 }}
                className="p-2 rounded-lg bg-accent/10 hover:bg-accent/20 smooth-transition"
              >
                <Twitter className="h-5 w-5 text-neon-cyan" />
              </motion.a>
              <motion.a
                href="#"
                whileHover={{ scale: 1.1 }}
                className="p-2 rounded-lg bg-accent/10 hover:bg-accent/20 smooth-transition"
              >
                <Mail className="h-5 w-5 text-neon-green" />
              </motion.a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-neon-purple">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <a href="/" className="text-muted-foreground hover:text-neon-blue smooth-transition">
                  Home
                </a>
              </li>
              <li>
                <a href="/main-ai-chat" className="text-muted-foreground hover:text-neon-blue smooth-transition">
                  AI Chat
                </a>
              </li>
              <li>
                <a href="/mini-bots-hub" className="text-muted-foreground hover:text-neon-blue smooth-transition">
                  Mini-Bots
                </a>
              </li>
            </ul>
          </div>

          {/* Features */}
          <div>
            <h3 className="text-lg font-semibold mb-4 text-neon-green">Features</h3>
            <ul className="space-y-2 text-muted-foreground">
              <li>AI-Powered Conversations</li>
              <li>Specialized Mini-Bots</li>
              <li>Real-time Streaming</li>
              <li>Contextual Understanding</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-border mt-8 pt-8 text-center">
          <p className="text-muted-foreground">
            &copy; 2024 Energize AI. Built with cutting-edge technology for the future.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;


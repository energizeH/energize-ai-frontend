import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Zap, Menu, X, Bot, Home, MessageSquare } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const navItems = [
    { path: '/', label: 'Home', icon: Home },
    { path: '/main-ai-chat', label: 'AI Chat', icon: MessageSquare },
    { path: '/mini-bots-hub', label: 'Mini-Bots', icon: Bot },
  ];

  return (
    <header className="sticky top-0 z-50 bg-card/80 backdrop-blur-md border-b border-border">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2 group">
            <motion.div
              whileHover={{ rotate: 360 }}
              transition={{ duration: 0.5 }}
              className="p-2 rounded-lg bg-primary/10 border border-primary/20"
            >
              <Zap className="h-6 w-6 text-neon-blue neon-glow" />
            </motion.div>
            <span className="text-xl font-bold text-neon-blue neon-text">
              Energize AI
            </span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-lg smooth-transition ${
                    isActive
                      ? 'text-neon-blue neon-glow bg-primary/10 border border-primary/20'
                      : 'text-muted-foreground hover:text-neon-purple hover:bg-accent/10'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{item.label}</span>
                </Link>
              );
            })}
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-accent/10 smooth-transition"
          >
            {isMenuOpen ? (
              <X className="h-6 w-6 text-neon-purple" />
            ) : (
              <Menu className="h-6 w-6 text-neon-blue" />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <motion.nav
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden py-4 border-t border-border"
          >
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setIsMenuOpen(false)}
                  className={`flex items-center space-x-3 px-4 py-3 rounded-lg smooth-transition ${
                    isActive
                      ? 'text-neon-blue neon-glow bg-primary/10 border border-primary/20'
                      : 'text-muted-foreground hover:text-neon-purple hover:bg-accent/10'
                  }`}
                >
                  <Icon className="h-5 w-5" />
                  <span>{item.label}</span>
                </Link>
              );
            })}
          </motion.nav>
        )}
      </div>
    </header>
  );
};

export default Header;


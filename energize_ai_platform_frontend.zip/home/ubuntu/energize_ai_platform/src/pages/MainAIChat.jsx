import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Bot, User, Loader2, Sparkles } from 'lucide-react';

const MainAIChat = () => {
  const [messages, setMessages] = useState([
    {
      id: 1,
      type: 'ai',
      content: 'Hello! I\'m your AI assistant powered by advanced language models. How can I help you today?',
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!inputValue.trim() || isLoading) return;

    const userMessage = {
      id: Date.now(),
      type: 'user',
      content: inputValue,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    try {
      const response = await fetch('http://localhost:3001/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message: inputValue, userId: 'user123' }), // Use a static userId for now
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      const aiMessage = {
        id: Date.now() + 1,
        type: 'ai',
        content: data.reply,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error('Error sending message to backend:', error);
      const errorMessage = {
        id: Date.now() + 1,
        type: 'ai',
        content: 'Oops! Something went wrong. Please try again later.',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-8"
          >
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              <span className="text-neon-blue neon-text">AI</span> Assistant
            </h1>
            <p className="text-muted-foreground">
              Powered by advanced language models for intelligent conversations
            </p>
          </motion.div>

          {/* Chat Container */}
          <div className="bg-card rounded-2xl border border-border shadow-lg overflow-hidden">
            {/* Messages Area */}
            <div className="h-96 md:h-[500px] overflow-y-auto p-6 space-y-4">
              <AnimatePresence>
                {messages.map((message) => (
                  <motion.div
                    key={message.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className={`flex items-start space-x-3 ${
                      message.type === 'user' ? 'flex-row-reverse space-x-reverse' : ''
                    }`}
                  >
                    {/* Avatar */}
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center border ${
                        message.type === 'ai'
                          ? 'bg-neon-blue/10 border-neon-blue/20 text-neon-blue'
                          : 'bg-neon-purple/10 border-neon-purple/20 text-neon-purple'
                      }`}
                    >
                      {message.type === 'ai' ? (
                        <Bot className="h-4 w-4" />
                      ) : (
                        <User className="h-4 w-4" />
                      )}
                    </div>

                    {/* Message Content */}
                    <div
                      className={`max-w-xs md:max-w-md lg:max-w-lg p-4 rounded-lg ${
                        message.type === 'ai'
                          ? 'bg-secondary text-secondary-foreground'
                          : 'bg-primary text-primary-foreground'
                      }`}
                    >
                      <p className="text-sm md:text-base">{message.content}</p>
                      <p className="text-xs opacity-70 mt-2">
                        {message.timestamp.toLocaleTimeString()}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>

              {/* Loading Indicator */}
              {isLoading && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-start space-x-3"
                >
                  <div className="w-8 h-8 rounded-full bg-neon-blue/10 border border-neon-blue/20 text-neon-blue flex items-center justify-center">
                    <Bot className="h-4 w-4" />
                  </div>
                  <div className="bg-secondary text-secondary-foreground p-4 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Loader2 className="h-4 w-4 animate-spin text-neon-blue" />
                      <span className="text-sm">AI is thinking...</span>
                    </div>
                  </div>
                </motion.div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <div className="border-t border-border p-6">
              <form onSubmit={handleSendMessage} className="flex space-x-4">
                <div className="flex-1 relative">
                  <input
                    type="text"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder="Type your message..."
                    className="w-full px-4 py-3 bg-input border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent smooth-transition"
                    disabled={isLoading}
                  />
                  <Sparkles className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                </div>
                <motion.button
                  type="submit"
                  disabled={!inputValue.trim() || isLoading}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-6 py-3 bg-primary hover:bg-primary/90 text-primary-foreground rounded-lg font-medium smooth-transition disabled:opacity-50 disabled:cursor-not-allowed neon-glow"
                >
                  <Send className="h-4 w-4" />
                </motion.button>
              </form>
              <p className="text-xs text-muted-foreground mt-2 text-center">
                Press Enter to send
              </p>
            </div>
          </div>

          {/* Features Info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4"
          >
            <div className="text-center p-4 bg-card/50 rounded-lg border border-border">
              <Bot className="h-8 w-8 text-neon-blue mx-auto mb-2" />
              <h3 className="font-semibold text-sm">Advanced AI</h3>
              <p className="text-xs text-muted-foreground">GPT-4o & Gemini Pro</p>
            </div>
            <div className="text-center p-4 bg-card/50 rounded-lg border border-border">
              <Sparkles className="h-8 w-8 text-neon-purple mx-auto mb-2" />
              <h3 className="font-semibold text-sm">Real-time Streaming</h3>
              <p className="text-xs text-muted-foreground">Instant responses</p>
            </div>
            <div className="text-center p-4 bg-card/50 rounded-lg border border-border">
              <User className="h-8 w-8 text-neon-green mx-auto mb-2" />
              <h3 className="font-semibold text-sm">Context Aware</h3>
              <p className="text-xs text-muted-foreground">Remembers conversation</p>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default MainAIChat;


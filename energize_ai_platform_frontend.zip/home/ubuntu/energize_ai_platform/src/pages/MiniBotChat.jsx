import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Bot, User, Loader2, Sparkles, ArrowLeft } from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';

const MiniBotChat = () => {
  const navigate = useNavigate();
  const { botId } = useParams();
  const [messages, setMessages] = useState([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [botInfo, setBotInfo] = useState(null);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    // Initialize bot conversation
    if (botId) {
      initializeBotChat();
    }
  }, [botId]);

  const initializeBotChat = async () => {
    try {
      const response = await fetch('http://localhost:3001/minibots');
      const data = await response.json();
      const bot = data.miniBots.find(b => b.id === botId);
      
      if (bot) {
        setBotInfo(bot);
        // Add initial greeting message
        const initialMessage = {
          id: 1,
          type: 'ai',
          content: `Hello! I'm ${bot.name}, ready to assist you with my specialized expertise. How can I help you today?`,
          timestamp: new Date()
        };
        setMessages([initialMessage]);
      } else {
        navigate('/mini-bots-hub');
      }
    } catch (error) {
      console.error('Error fetching bot info:', error);
      navigate('/mini-bots-hub');
    }
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!inputValue.trim() || isLoading) return;

    const userMessage = {
      id: Date.now(),
      type: 'user',
      content: inputValue,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    try {
      const response = await fetch('http://localhost:3001/minibot-chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          message: inputValue, 
          userId: 'user123', 
          botId: botId 
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      const aiMessage = {
        id: Date.now() + 1,
        type: 'ai',
        content: data.reply,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error('Error sending message to mini-bot:', error);
      const errorMessage = {
        id: Date.now() + 1,
        type: 'ai',
        content: 'Oops! Something went wrong. Please try again later.',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  if (!botInfo) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin text-neon-blue mx-auto mb-4" />
          <p className="text-muted-foreground">Loading bot...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-8"
          >
            <div className="flex items-center justify-center mb-4">
              <button
                onClick={() => navigate('/mini-bots-hub')}
                className="mr-4 p-2 rounded-lg hover:bg-accent/10 smooth-transition"
              >
                <ArrowLeft className="h-5 w-5 text-muted-foreground" />
              </button>
              <h1 className="text-3xl md:text-4xl font-bold">
                <span className={`text-${botInfo.color} neon-text`}>{botInfo.name}</span>
              </h1>
            </div>
            <p className="text-muted-foreground">
              Specialized AI assistant ready to help you
            </p>
          </motion.div>

          {/* Chat Container */}
          <div className="bg-card rounded-2xl border border-border shadow-lg overflow-hidden">
            {/* Messages Area */}
            <div className="h-96 md:h-[500px] overflow-y-auto p-6 space-y-4">
              <AnimatePresence>
                {messages.map((message) => (
                  <motion.div
                    key={message.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className={`flex items-start space-x-3 ${
                      message.type === 'user' ? 'flex-row-reverse space-x-reverse' : ''
                    }`}
                  >
                    {/* Avatar */}
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center border ${
                        message.type === 'ai'
                          ? `bg-${botInfo.color}/10 border-${botInfo.color}/20 text-${botInfo.color}`
                          : 'bg-neon-purple/10 border-neon-purple/20 text-neon-purple'
                      }`}
                    >
                      {message.type === 'ai' ? (
                        <Bot className="h-4 w-4" />
                      ) : (
                        <User className="h-4 w-4" />
                      )}
                    </div>

                    {/* Message Content */}
                    <div
                      className={`max-w-xs md:max-w-md lg:max-w-lg p-4 rounded-lg ${
                        message.type === 'ai'
                          ? 'bg-secondary text-secondary-foreground'
                          : 'bg-primary text-primary-foreground'
                      }`}
                    >
                      <p className="text-sm md:text-base">{message.content}</p>
                      <p className="text-xs opacity-70 mt-2">
                        {message.timestamp.toLocaleTimeString()}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>

              {/* Loading Indicator */}
              {isLoading && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-start space-x-3"
                >
                  <div className={`w-8 h-8 rounded-full bg-${botInfo.color}/10 border border-${botInfo.color}/20 text-${botInfo.color} flex items-center justify-center`}>
                    <Bot className="h-4 w-4" />
                  </div>
                  <div className="bg-secondary text-secondary-foreground p-4 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Loader2 className={`h-4 w-4 animate-spin text-${botInfo.color}`} />
                      <span className="text-sm">{botInfo.name} is thinking...</span>
                    </div>
                  </div>
                </motion.div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <div className="border-t border-border p-6">
              <form onSubmit={handleSendMessage} className="flex space-x-4">
                <div className="flex-1 relative">
                  <input
                    type="text"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder={`Ask ${botInfo.name} anything...`}
                    className="w-full px-4 py-3 bg-input border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent smooth-transition"
                    disabled={isLoading}
                  />
                  <Sparkles className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                </div>
                <motion.button
                  type="submit"
                  disabled={!inputValue.trim() || isLoading}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-6 py-3 bg-primary hover:bg-primary/90 text-primary-foreground rounded-lg font-medium smooth-transition disabled:opacity-50 disabled:cursor-not-allowed neon-glow"
                >
                  <Send className="h-4 w-4" />
                </motion.button>
              </form>
              <p className="text-xs text-muted-foreground mt-2 text-center">
                Press Enter to send • Powered by specialized AI
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MiniBotChat;


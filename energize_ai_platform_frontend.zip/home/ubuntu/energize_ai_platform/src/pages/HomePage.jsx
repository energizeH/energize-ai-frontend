import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight, Zap, Bot, MessageSquare, Sparkles, Brain, Target } from 'lucide-react';

const HomePage = () => {
  const features = [
    {
      icon: MessageSquare,
      title: 'Main AI Assistant',
      description: 'Engage in intelligent conversations with our advanced AI powered by GPT-4o and Gemini Pro.',
      color: 'text-neon-blue',
      bgColor: 'bg-neon-blue/10',
      borderColor: 'border-neon-blue/20'
    },
    {
      icon: Bot,
      title: 'Specialized Mini-Bots',
      description: 'Access purpose-built AI assistants for productivity, mindset, planning, and more.',
      color: 'text-neon-purple',
      bgColor: 'bg-neon-purple/10',
      borderColor: 'border-neon-purple/20'
    },
    {
      icon: Sparkles,
      title: 'Real-time Streaming',
      description: 'Experience instant AI responses with our optimized streaming technology.',
      color: 'text-neon-green',
      bgColor: 'bg-neon-green/10',
      borderColor: 'border-neon-green/20'
    },
    {
      icon: Brain,
      title: 'Contextual Understanding',
      description: 'Our AI maintains conversation context for more meaningful interactions.',
      color: 'text-neon-pink',
      bgColor: 'bg-neon-pink/10',
      borderColor: 'border-neon-pink/20'
    },
    {
      icon: Target,
      title: 'Goal-Oriented',
      description: 'Set and track your objectives with AI-powered planning and motivation.',
      color: 'text-neon-cyan',
      bgColor: 'bg-neon-cyan/10',
      borderColor: 'border-neon-cyan/20'
    },
    {
      icon: Zap,
      title: 'Lightning Fast',
      description: 'Optimized for performance with cutting-edge technology stack.',
      color: 'text-neon-blue',
      bgColor: 'bg-neon-blue/10',
      borderColor: 'border-neon-blue/20'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 lg:py-32">
        <div className="absolute inset-0 neon-gradient opacity-30"></div>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="mb-8"
            >
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6">
                <span className="text-neon-blue neon-text">Energize</span>{' '}
                <span className="text-foreground">Your</span>{' '}
                <span className="text-neon-purple neon-text">AI</span>
              </h1>
              <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-3xl mx-auto">
                The next-generation AI assistant platform that combines cutting-edge technology 
                with intuitive design to supercharge your productivity and creativity.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="flex flex-col sm:flex-row gap-4 justify-center items-center"
            >
              <Link
                to="/main-ai-chat"
                className="group flex items-center space-x-2 bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-4 rounded-lg font-semibold smooth-transition neon-glow"
              >
                <MessageSquare className="h-5 w-5" />
                <span>Start Chatting</span>
                <ArrowRight className="h-5 w-5 group-hover:translate-x-1 smooth-transition" />
              </Link>
              
              <Link
                to="/mini-bots-hub"
                className="group flex items-center space-x-2 bg-accent hover:bg-accent/90 text-accent-foreground px-8 py-4 rounded-lg font-semibold smooth-transition border border-accent/20"
              >
                <Bot className="h-5 w-5" />
                <span>Explore Mini-Bots</span>
                <ArrowRight className="h-5 w-5 group-hover:translate-x-1 smooth-transition" />
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-card/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              <span className="text-neon-green neon-text">Powerful</span> Features
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Experience the future of AI interaction with our comprehensive suite of intelligent tools.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  whileHover={{ scale: 1.05 }}
                  className={`p-6 rounded-lg bg-card border ${feature.borderColor} smooth-transition hover:shadow-lg`}
                >
                  <div className={`w-12 h-12 rounded-lg ${feature.bgColor} border ${feature.borderColor} flex items-center justify-center mb-4`}>
                    <Icon className={`h-6 w-6 ${feature.color}`} />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center bg-card rounded-2xl p-12 border border-border neon-gradient"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Ready to <span className="text-neon-blue neon-text">Energize</span> Your Workflow?
            </h2>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Join the future of AI-powered productivity and unlock your potential with our intelligent assistant platform.
            </p>
            <Link
              to="/main-ai-chat"
              className="inline-flex items-center space-x-2 bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-4 rounded-lg font-semibold smooth-transition neon-glow"
            >
              <Zap className="h-5 w-5" />
              <span>Get Started Now</span>
              <ArrowRight className="h-5 w-5" />
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;


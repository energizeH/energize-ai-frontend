import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Bot, Brain, Target, Lightbulb, Heart, Zap, ArrowRight, MessageSquare } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const MiniBotsHub = () => {
  const navigate = useNavigate();
  const [selectedBot, setSelectedBot] = useState(null);
  const [miniBots, setMiniBots] = useState([]);

  useEffect(() => {
    // Fetch mini-bots from backend
    fetchMiniBots();
  }, []);

  const fetchMiniBots = async () => {
    try {
      const response = await fetch('http://localhost:3001/minibots');
      const data = await response.json();
      
      // Map backend data with frontend icons and descriptions
      const botsWithDetails = data.miniBots.map(bot => ({
        ...bot,
        icon: getIconForBot(bot.id),
        description: getDescriptionForBot(bot.id),
        features: getFeaturesForBot(bot.id)
      }));
      
      setMiniBots(botsWithDetails);
    } catch (error) {
      console.error('Error fetching mini-bots:', error);
      // Fallback to static data if backend is not available
      setMiniBots(getStaticMiniBots());
    }
  };

  const getIconForBot = (botId) => {
    const iconMap = {
      'focus-bot': Target,
      'mindset-bot': Brain,
      'planner-bot': Lightbulb,
      'wellness-bot': Heart,
      'creative-bot': Zap
    };
    return iconMap[botId] || Bot;
  };

  const getDescriptionForBot = (botId) => {
    const descriptions = {
      'focus-bot': 'Your productivity companion for time-blocking, distraction management, and deep work optimization.',
      'mindset-bot': 'Daily affirmations, mindset coaching, and mental wellness support for peak performance.',
      'planner-bot': 'Strategic planning assistant for goals, projects, and long-term vision development.',
      'wellness-bot': 'Holistic wellness guidance covering physical health, mental balance, and lifestyle optimization.',
      'creative-bot': 'Creative inspiration, brainstorming assistance, and innovative problem-solving support.'
    };
    return descriptions[botId] || 'Specialized AI assistant ready to help you.';
  };

  const getFeaturesForBot = (botId) => {
    const features = {
      'focus-bot': ['Time-blocking strategies', 'Distraction elimination', 'Focus techniques', 'Productivity planning'],
      'mindset-bot': ['Daily affirmations', 'Mindset coaching', 'Confidence building', 'Mental wellness'],
      'planner-bot': ['Goal setting', 'Project planning', 'Strategic thinking', 'Vision development'],
      'wellness-bot': ['Health guidance', 'Stress management', 'Work-life balance', 'Wellness tips'],
      'creative-bot': ['Creative brainstorming', 'Idea generation', 'Innovation techniques', 'Artistic inspiration']
    };
    return features[botId] || ['Specialized assistance', 'Expert guidance', 'Personalized support'];
  };

  const getStaticMiniBots = () => [
    {
      id: 'focus-bot',
      name: 'FocusBot',
      color: 'neon-blue',
      icon: Target,
      description: 'Your productivity companion for time-blocking, distraction management, and deep work optimization.',
      features: ['Time-blocking strategies', 'Distraction elimination', 'Focus techniques', 'Productivity planning']
    },
    {
      id: 'mindset-bot',
      name: 'MindsetBot',
      color: 'neon-purple',
      icon: Brain,
      description: 'Daily affirmations, mindset coaching, and mental wellness support for peak performance.',
      features: ['Daily affirmations', 'Mindset coaching', 'Confidence building', 'Mental wellness']
    },
    {
      id: 'planner-bot',
      name: 'PlannerBot',
      color: 'neon-green',
      icon: Lightbulb,
      description: 'Strategic planning assistant for goals, projects, and long-term vision development.',
      features: ['Goal setting', 'Project planning', 'Strategic thinking', 'Vision development']
    },
    {
      id: 'wellness-bot',
      name: 'WellnessBot',
      color: 'neon-pink',
      icon: Heart,
      description: 'Holistic wellness guidance covering physical health, mental balance, and lifestyle optimization.',
      features: ['Health guidance', 'Stress management', 'Work-life balance', 'Wellness tips']
    },
    {
      id: 'creative-bot',
      name: 'CreativeBot',
      color: 'neon-cyan',
      icon: Zap,
      description: 'Creative inspiration, brainstorming assistance, and innovative problem-solving support.',
      features: ['Creative brainstorming', 'Idea generation', 'Innovation techniques', 'Artistic inspiration']
    }
  ];

  const handleBotSelect = (bot) => {
    setSelectedBot(bot);
    // Navigate to dedicated chat interface
    navigate(`/minibot-chat/${bot.id}`);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              <span className="text-neon-purple neon-text">Mini-Bots</span> Hub
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Choose from our collection of specialized AI assistants, each expertly trained 
              for specific tasks and optimized with advanced prompt engineering.
            </p>
          </motion.div>

          {/* Bots Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {miniBots.map((bot, index) => {
              const Icon = bot.icon;
              return (
                <motion.div
                  key={bot.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                  whileHover={{ scale: 1.02, y: -5 }}
                  className={`p-6 rounded-xl bg-card border border-${bot.color}/20 smooth-transition hover:shadow-lg cursor-pointer group`}
                  onClick={() => handleBotSelect(bot)}
                >
                  {/* Bot Icon and Name */}
                  <div className="flex items-center space-x-3 mb-4">
                    <div className={`w-12 h-12 rounded-lg bg-${bot.color}/10 border border-${bot.color}/20 flex items-center justify-center group-hover:scale-110 smooth-transition`}>
                      <Icon className={`h-6 w-6 text-${bot.color}`} />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold">{bot.name}</h3>
                      <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                        <Bot className="h-3 w-3" />
                        <span>Specialized AI</span>
                      </div>
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-muted-foreground mb-4 text-sm leading-relaxed">
                    {bot.description}
                  </p>

                  {/* Features */}
                  <div className="space-y-2 mb-6">
                    {bot.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center space-x-2 text-sm">
                        <div className={`w-1.5 h-1.5 rounded-full bg-${bot.color}`}></div>
                        <span className="text-muted-foreground">{feature}</span>
                      </div>
                    ))}
                  </div>

                  {/* Action Button */}
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className={`w-full flex items-center justify-center space-x-2 py-3 px-4 rounded-lg bg-${bot.color}/10 border-${bot.color}/20 border text-${bot.color} font-medium smooth-transition group-hover:neon-glow`}
                  >
                    <MessageSquare className="h-4 w-4" />
                    <span>Chat with {bot.name}</span>
                    <ArrowRight className="h-4 w-4 group-hover:translate-x-1 smooth-transition" />
                  </motion.button>
                </motion.div>
              );
            })}
          </div>

          {/* Info Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="mt-12 text-center bg-card/50 rounded-xl p-8 border border-border"
          >
            <h2 className="text-2xl font-bold mb-4">
              <span className="text-neon-blue neon-text">Advanced</span> Prompt Engineering
            </h2>
            <p className="text-muted-foreground max-w-3xl mx-auto">
              Each mini-bot is powered by sophisticated prompt engineering techniques, ensuring 
              specialized, consistent, and highly effective AI interactions tailored to specific use cases.
            </p>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default MiniBotsHub;


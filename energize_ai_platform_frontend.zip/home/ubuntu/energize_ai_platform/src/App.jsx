import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import MainAIChat from './pages/MainAIChat';
import MiniBotsHub from './pages/MiniBotsHub';
import MiniBotChat from './pages/MiniBotChat';
import Layout from './components/Layout';
import './App.css';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<HomePage />} />
          <Route path="main-ai-chat" element={<MainAIChat />} />
          <Route path="mini-bots-hub" element={<MiniBotsHub />} />
          <Route path="minibot-chat/:botId" element={<MiniBotChat />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;



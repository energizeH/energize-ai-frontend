require("dotenv").config();
const express = require("express");
const cors = require("cors");
const { GoogleGenerativeAI } = require("@google/generative-ai");
const miniBotConfigs = require("./miniBotConfigs");

const app = express();
const port = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());

// Initialize Google Generative AI
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// Store conversation history for context
const conversationHistory = {}; // In a real app, this would be stored per user in a database
const miniBotSessions = {}; // Store mini-bot specific sessions

app.post("/chat", async (req, res) => {
  const { message, userId } = req.body;

  if (!message) {
    return res.status(400).json({ error: "Message is required" });
  }

  // Get or create model and chat session for the user
  if (!conversationHistory[userId]) {
    const model = genAI.getGenerativeModel({ model: "gemini-pro" });
    conversationHistory[userId] = {
      model: model,
      chat: model.startChat({
        history: [],
        generationConfig: {
          maxOutputTokens: 500,
        },
      }),
    };
  }
  const chat = conversationHistory[userId].chat;

  try {
    const result = await chat.sendMessage(message);
    const response = await result.response;
    const text = response.text();

    res.json({ reply: text });
  } catch (error) {
    console.error("Error communicating with Gemini API:", error);
    res.status(500).json({ error: "Failed to get response from AI" });
  }
});

app.post("/minibot-chat", async (req, res) => {
  const { message, userId, botId } = req.body;

  if (!message || !botId) {
    return res.status(400).json({ error: "Message and botId are required" });
  }

  const botConfig = miniBotConfigs[botId];
  if (!botConfig) {
    return res.status(400).json({ error: "Invalid bot ID" });
  }

  // Create unique session key for user + bot combination
  const sessionKey = `${userId}-${botId}`;

  // Get or create model and chat session for the specific mini-bot
  if (!miniBotSessions[sessionKey]) {
    const model = genAI.getGenerativeModel({ model: "gemini-pro" });
    miniBotSessions[sessionKey] = {
      model: model,
      chat: model.startChat({
        history: [
          {
            role: "user",
            parts: [{ text: botConfig.systemPrompt }]
          },
          {
            role: "model",
            parts: [{ text: `Hello! I'm ${botConfig.name}, ready to assist you with my specialized expertise. How can I help you today?` }]
          }
        ],
        generationConfig: {
          maxOutputTokens: 500,
        },
      }),
    };
  }
  const chat = miniBotSessions[sessionKey].chat;

  try {
    const result = await chat.sendMessage(message);
    const response = await result.response;
    const text = response.text();

    res.json({ 
      reply: text,
      botName: botConfig.name,
      botId: botId
    });
  } catch (error) {
    console.error("Error communicating with Gemini API for mini-bot:", error);
    res.status(500).json({ error: "Failed to get response from AI" });
  }
});

app.get("/minibots", (req, res) => {
  // Return available mini-bots configuration (without system prompts for security)
  const publicConfigs = Object.keys(miniBotConfigs).map(key => ({
    id: key,
    name: miniBotConfigs[key].name,
    color: miniBotConfigs[key].color,
    icon: miniBotConfigs[key].icon
  }));
  
  res.json({ miniBots: publicConfigs });
});

app.get("/", (req, res) => {
  res.send("Energize AI Backend is running!");
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});

